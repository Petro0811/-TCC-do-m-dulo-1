

switch(state)
{

case "free":

up = keyboard_check(vk_up)
down = keyboard_check(vk_down)
right = keyboard_check(vk_right)
left = keyboard_check(vk_left)

hsp = (right - left) * spd
vsp = (down - up) * spd

var layer_sequenceid = layer_get_id("sequences")

if place_meeting(x,y,obj_next_level)
{
	state = "incutscene"
	hsp = 0
	vsp = 0
	layer_sequence_create(layer_sequenceid,x,y,sqc_transition_start)

}

break;

case "incutscene":

break;

}